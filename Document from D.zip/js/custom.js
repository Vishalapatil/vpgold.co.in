if (window.localStorage.getItem("username")) {

    if (window.localStorage.getItem("password")) {

        $("#IdTrades").css("display", "flex");
        $("#IdOrders").css("display", "flex");
        $("#openaccountbtn").css("display", "none");
        $("#loginbtn").css("display", "flex");


    }

}
