
function removeAllRowsFromTable() {
    //alert("11");
    $("#gvData").empty();
}

function gvData_Trending() {
    $("#gvData_Trending").empty();

}



//Silver Rates
function removeAllRowsFromTable_gvData_SilverRates() {
    $("#gvData_SilverRates").empty();
}

function gvData_Trending_gvData_Trending_SilverRates() {
    $("#gvData_Trending_SilverRates").empty();

}


function gvData_Trending_gvData_Trending_GoldRates() {
    $("#gvData_Trending_GoldRates").empty();

}





function gvData_Gold_Silver_INR_coinss() {
    $("#gvData_Gold_Silver_INR_coinss").empty();
}





function callBuySell(scripCode, scripName) {

    //alert(scripCode);
    //alert(scripName);
    //startSpinner();

    sessionStorage.scripname = scripName;
    sessionStorage.scripcode = scripCode;

    window.location.href = "www/BuySell.htm";

}

function fnStartClock() {

    try {
        //CallWebServiceFromJqueryLiveRateMessage();
        //alert("fnStartClock");
        refreshData();

        oInterval = setInterval("refreshData()", 500);
        CallWebServiceFromJqueryMarquee();
        var timerMarquee = setInterval("CallWebServiceFromJqueryMarquee()", 30000);
    }
    catch (e) {
        // alert("fnStartClock" + e);
    }
}

function refreshData() {
    CallWebServiceFromJquery();
               CallWebServiceFromJqueryGoldCoins();
    //            CallWebServiceFromJquerySilverCoins();
}

function fnStopClock() {
    try {
        clearInterval(oInterval);
    }
    catch (e) {
        //  alert("fnStopClock" + e);
    }
}


function addZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function updateTime() {
    var d = new Date();
    var x = document.getElementById("cur_time");
    var h = addZero(d.getHours());
    var m = addZero(d.getMinutes());
    var s = addZero(d.getSeconds());
    var ampm = h >= 12 ? 'pm' : 'am';
    h = h % 12;
    h = h ? h : 12; // the hour '0' should be '12'
    x.innerHTML = h + ":" + m + ":" + s;
}
var maxRows = 0;
var oldData;
var oldData01;
var oldData02;
var oldData03;
var screenFontSize = 14;
var oldDataTop;
var oldDataGoldCoins;
var oldDataSilverCoins;
var counterRefresh = 0;



//Spotttttttttttttttttttt
function CallWebServiceFromJquery() {
    try {


        var template = localStorage.defaultScripTemplateId;

        if (TemplateID) {
            template = TemplateID;
        }
// alert(template);

        // alert("http://bulliontradingbcast.chirayusoft.com:7767/VOTSBroadcastStreaming/Services/xml/GetLiveRateByTemplateID/" + template);
        $.ajax({
            type: "GET",
            url: "http://" + localStorage.ipAddressBCast + ":" + localStorage.step3StreamingPort + "/VOTSBroadcastStreaming/Services/xml/GetLiveRateByTemplateID/" + template,
            dataType: "text",
            crossDomain: true,
            processData: false,
            success: OnSuccess,
            error: OnError,
            cache: false
        });
    }
    catch (e) {
        //alert("CallWebServiceFromJquery " + e);
    }

}

var myColor_Background = "#0d1539";
var Color_ForeColor = "#000";
var Color_ScriptColor = "#141e46";

var Script_Font_LiveRatesCoins = "32px";
var Change_ScriptNameFont = "13px";


//Spottttttttttttttttttt
function OnSuccess(data, status) {
    //alert(data);
    try {
        //updateTime();
        //stopSpinner();


        var messagesDesktopp = "";
        messagesDesktopp = data.split("\n");
        //alert(messagesDesktopp.length);
        if (typeof oldData != 'undefined') {

        }
        else {
            //alert("1");
            oldData = data.toString();
        }
        var messagesOldDesktop = oldData.split("\n");

        if (typeof messagesDesktopp != 'undefined') {
            if (maxRows == 0) {
                maxRows = messagesDesktopp.length;
            }
             
            removeAllRowsFromTable();
            var zebra = "";
            zebra = document.getElementById("gvData"); //Desktopppppppppppppppppppppppppppp
            var trow = "";
            //GOLD
            var retDesktop = "";
            retDesktop = messagesDesktopp[0].split("\t");
            //alert(retDesktop.length);
            var oldRetDesktop = "";
            var trowString = "";
            oldRetDesktop = messagesOldDesktop[0].split("\t");

            if (typeof retDesktop[2] != 'undefined') {

                trowString = trowString + "<table class=\"table1001\" style=\"margin-top:1%;background: linear-gradient(to top, #fff 41%, #afcb1f 10%);background-size: 50% auto;\"><tr><td align=\"center\" style=\"width: 25%;\">";

                if (retDesktop[3] > oldRetDesktop[3]) {
                    trowString = trowString + "<table  width=\"100%\"  style=\"\"><tr style=\"\"><td class=\"sell\" style=\"color:#fff;text-align:center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#000;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:green;\">" + retDesktop[3] + "</span></td></tr>" +
                                                "<tr>" +
                                                    "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                                                "</tr>" +
                                                "</table>";
                }
                else if (retDesktop[3] < oldRetDesktop[3]) {
                    trowString = trowString + "<table  width=\"100%\"  style=\"\"><tr style=\"\"><td class=\"sell\" style=\"color:#fff;text-align:center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#000;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:red;\">" + retDesktop[3] + "</span></td></tr>" +
                                                "<tr>" +
                                                    "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                                                "</tr>" +
                                                "</table>";
                }
                else {
                    trowString = trowString + "<table  width=\"100%\" style=\"\"><tr style=\"\"><td class=\"sell\" style=\"color:#fff;text-align:center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#000;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:#000;\">" + retDesktop[3] + "</span></td></tr>" +
                                                "<tr>" +
                                                    "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                                                "</tr>" +
                                              "</table>";
                }

                trowString = trowString + "</td>";

                //}
            }
            //SILVER
            retDesktop = messagesDesktopp[1].split("\t");
            oldRetDesktop = messagesOldDesktop[1].split("\t");
            if (typeof retDesktop[2] != 'undefined') {

                if (retDesktop[3] > oldRetDesktop[3]) {

                    trowString = trowString + "<td align=\"center\" style=\"width: 25%;\"><table  width=\"100%\"  style=\"\"><tr><td style=\"color:#fff;text-align: center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#FFF;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:green;\">" + retDesktop[3] + "</span></td></tr>" +
                        "<tr>" +
                            "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                        "</tr>" +
                    "</table></td>";

                }
                else if (retDesktop[3] < oldRetDesktop[3]) {
                    trowString = trowString + "<td align=\"center\" style=\"width: 25%;\"><table  width=\"100%\"  style=\"\"><tr><td style=\"color:#fff;text-align: center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#FFF;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:red;\">" + retDesktop[3] + "</span></td></tr>" +
                            "<tr>" +
                                "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                            "</tr>" +
                            "</table></td>";
                }
                else {
                    trowString = trowString + "<td align=\"center\" style=\"width: 25%;\"><table  width=\"100%\"  style=\"\"><tr><td style=\"color:#fff;text-align: center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#000;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:#000;\">" + retDesktop[3] + "</span></td></tr>" +
                        "<tr>" +
                            "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                        "</tr>" +
                    "</table></td>";
                }

            }
            //INR
            retDesktop = messagesDesktopp[2].split("\t");
            oldRetDesktop = messagesOldDesktop[2].split("\t");
            if (typeof retDesktop[2] != 'undefined') {
                var trowString;
                //if (deletedScrips[2] != "0") {
                if (retDesktop[3] > oldRetDesktop[3]) {


                    trowString = trowString + "<td style=\"width:25%;\" align=\"center\"><table  width=\"100%\" style=\"\"><tr><td style=\"color:#fff;text-align: center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#FFF;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:green;\">" + retDesktop[3] + "</span></td></tr>" +
                                                "<tr>" +
                                                    "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                                                "</tr>" +
                    "</table></table></td>"

                }
                else if (retDesktop[3] < oldRetDesktop[3]) {

                    trowString = trowString + "<td style=\"width:25%;\" align=\"center\"><table width=\"100%\" style=\"\"><tr><td style=\"color:#fff;text-align: center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#FFF;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:red;\">" + retDesktop[3] + "</span></td></tr>" +
                                                "<tr>" +
                                                    "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                                                "</tr>" +
                    "</table></table></td>";
                }
                else {

                    trowString = trowString + "<td style=\"width:25%;\" align=\"center\"><table  width=\"100%\" style=\"\"><tr><td style=\"color:#fff;text-align: center !Important;font-size: 16px;font-weight:700;\">" + retDesktop[2] + "</td></tr><table  width=\"100%\" id=\"gold\" class=\"goldd\" style=\"\"><tr><td id=\"" + retDesktop[1] + "BUY\" style=\"color:#FFF;text-align: center !Important;font-size: 16px;\"><span class=\"top5span\" style=\"color:#000\">" + retDesktop[3] + "</span></td></tr>" +
                                                "<tr>" +
                                                    "<td style=\"color: #000;text-align: center !Important;\"><span class=\"bloc_GS\" style=\"color:red;\">" + retDesktop[6] + "</span> | <span class=\"bloc_GS\" style=\"color:green;\">" + retDesktop[5] + "</span></td>" +
                                                "</tr>" +
                    "</table></table></td>";
                }


                //}
            }

            trowString = trowString + "</tr></table>";







                        trowString = trowString + "<table class=\"tt_33\" width=\"100%\" style=\"margin-top:0%;border-collapse:separate;\"> " +
                                                        " <tr > " +
                                                            " <td style=\"padding: 0px 0px 0;\"> " +
                                                                "<table  width=\"100%\" style=\"margin-bottom:1%;background:#ef7f1b;\"> " +
                                                                "<tr>" +
                                                                    "<td width=\"50%\" style=\"font-size: 16px;color:#fff;font-weight:BOLD;padding: 10px 0px 10px 20px;text-align:left; \">" +
                        												"<span>COMMODITY</span>" +
                                                                    "</td>" +
                                                                    "<td width=\"25%\" style=\"font-size: 16px;padding:0px 3px;color:#fff;font-weight:BOLD;text-align:center; \" >" +
                                                                        "<span>BUY</span>" +
                                                                    "</td>" +

                                                                    "<td width=\"25%\" style=\"font-size: 16px;padding:0px 3px ;color:#fff;font-weight:BOLD;text-align:center; \" >" +
                                                                        "<span>SELL</span>" +
                                                                    "</td>" +

                                                                    // "<td width=\"25%\" style=\"font-size: 16px;padding:5px 3px;color:#000;font-weight:BOLD;text-align:center; \" >" +
                                                                    //     "<span>H/L</span>" +
                                                                    // "</td>" +

                        //                                                                "<td style=\"width:20%; text-align: center !Important\" >" +
                        //                                                                    "<span></span>" +
                        //                                                                "</td>" +

                        //"<td style=\"width:15%; text-align: center !Important\" >" +
                        //   "<span>L</span>" +
                        //"</td>" +
                                                                    "</tr>" +
                                                                "</table>"
                        "</td>" +
                                                            "</tr>" +
                        //Second Row
                                                                 " <tr> " +
                                                              " <td style=\"\"> ";
            //messages.length
            //messages.length
        for (var i = 5; i < messagesDesktopp.length; i++) {
        //var ret = jQuery.parseJSON(messages[i]);
        var ret = messagesDesktopp[i].split("\t");
        var oldRet;


        oldRet = messagesOldDesktop[i].split("\t");
		
		var background1 = "img/ratebox.png";


                if (ret[2].toLowerCase().includes("gold")) {
                    background1 = "#afcb1f ";
                }
               
                else if (ret[2].toLowerCase().includes("silver")) {
					
					
					background1 = "#d59969";
				}
        if (typeof ret[1] != 'undefined') {

            if (ret[3] > oldRet[3]) {

                trowString = trowString +
                //"<table width=\"100%\"><tr><td onclick=\"callBuySell('" + ret[1] + "')\" >" +
                                    "<table class=\"res_mob_font_width\"  width=\"100%\" style=\"border-collapse:separate;border-spacing:5px;\"> " +
                                        "<tr onclick=\"callBuySell('" + ret[1] + "','" + ret[2] + "');\" style=\"text-align: center;\"> " +
                                            "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:left;font-weight:700;color:#ef7f1b;text-transform:uppercase;\">" + ret[2] + "</td> " +
                                            "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                            "<span id=\"mainspan\" style=\"padding-bottom:0 !important; padding:0px 3px;font-size: 32px; color:#fff;font-weight:700;background:green;border-radius:0px;\">" + ret[3] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:red;font-weight:700;padding-bottom:0 !important;\"><br> L : " + ret[6] + "</span>" +
                                            "</td>";

            }
            else if (ret[3] < oldRet[3]) {

                trowString = trowString +
                //                                "<table width=\"100%\">"+
                //                                    "<tr>"+
                //                                        "<td>"+
                                    "<table class=\"res_mob_font_width\" width=\"100%\" style=\"border-collapse:separate;border-spacing:5px;\">" +
                                        "<tr onclick=\"callBuySell('" + ret[1] + "','" + ret[2] + "');\"  style=\"text-align: center;\">" +
                                            "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:left;font-weight:700;color:#ef7f1b;text-transform:uppercase;\">" + ret[2] + "</td>" +
                                            "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                            "<span id=\"mainspan\" style=\" padding:0px 3px;padding-bottom:0 !important; font-size: 32px; color:#fff;font-weight:700;background:red;border-radius:0px;\">" + ret[3] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:red;font-weight:700;padding-bottom:0 !important;\"><br> L : " + ret[6] + "</span>" +
                                            "</td>";

            }
            else {
                trowString = trowString +
                //                                    "<table width=\"100%\">"+
                //                                        "<tr>"+
                //                                            "<td>"+
                                        "<table class=\"res_mob_font_width\" width=\"100%\" style=\"border-collapse:separate;border-spacing:5px;\">" +
                                            "<tr onclick=\"callBuySell('" + ret[1] + "','" + ret[2] + "');\"  style=\"text-align: center;\">" +
                                                "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:left;font-weight:700;color:#ef7f1b;text-transform:uppercase;\">" + ret[2] + "</td>" +
                                                "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                                "<span id=\"mainspan\" style=\"  padding:0px 3px;font-size: 32px;color:#000;font-weight:700;padding-bottom:0 !important;\">" + ret[3] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:red;font-weight:700;padding-bottom:0 !important;\"><br> L : " + ret[6] + "</span>" +
                                                "</td>";

            }





            //For Sell

            if (ret[4] > oldRet[4]) {

                trowString = trowString +
                                "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                "<span id=\"mainspan\" style=\" padding:0px 3px;font-size: 32px;color:#fff;font-weight:700;background:green;border-radius:0px;padding-bottom:0 !important;\">" + ret[4] + "</span>" + //<br/><span style=\"color:#8ce08c;\">H : " + ret[5] + "</span>
                "<span style=\"padding: 5px;font-size: 12px;color:green;font-weight:700;padding-bottom:0 !important;\"><br> H : " + ret[5] + "</span>" +
                                "</td>";
            }
            else if (ret[4] < oldRet[4]) {

                trowString = trowString +

                                            "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                //"<span style=\"font-size: 17px;background-color:#d0161e;border-radius:10px;color:#FFF;font-weight:700\">" + sellSmall + "</span>
                                            "<span id=\"mainspan\" style=\" padding:0px 3px;font-size: 32px;color:#fff;padding-bottom:0 !important;font-weight:700;background:red;border-radius:0px;\">" + ret[4] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:green;font-weight:700;padding-bottom:0 !important;\"><br>  H : " + ret[5] + "</span>" +
                                            "</td>";

            }
            else {
                trowString = trowString +

                                                "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                //<span style=\"font-size: 17px; padding:1px 5px;padding: 3px;font-weight:700;color:#FFF\">" + sellSmall + "</span>
                                                "<span id=\"mainspan\" style=\"font-size: 32px; padding:0px 3px;font-weight:700;color:#000;padding-bottom:0 !important;\">" + ret[4] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:green;font-weight:700;\"><br> H : " + ret[5] + "</span>" +
                                                "</td>";
            }



            //trowString = trowString + "</td></tr></table>";
            // trowString = trowString + "<td style=\"width: 25%;\"><span style=\"text-align: center !Important;font-size: 16px !important;color:#fff;\">" + ret[5] + "</span> / <span style=\"text-align: center !Important;font-size: 16px !important;color:#fff;\">" + ret[6] + "</span></td>";
            trowString = trowString + "</tr></table>";

            //}

        }
        oldData = data.toString();

    }
    trowString = trowString + "</td></tr></table>"; //</td></tr>



trowString = trowString + "<table class=\"tt_33\" width=\"100%\" style=\"margin-top:0%;border-collapse:separate;\"> " +
                                                        " <tr > " +
                                                            " <td style=\"padding: 0px 0px 0;\"> " +
                                                                "<table  width=\"100%\" style=\"margin-bottom:1%;background:#ef7f1b;\"> " +
                                                                "<tr>" +
                                                                    "<td width=\"50%\" style=\"font-size: 16px;color:#fff;font-weight:BOLD;padding: 10px 0px 10px 20px;text-align:left; \">" +
                        												"<span>FUTURE</span>" +
                                                                    "</td>" +
                                                                    "<td width=\"25%\" style=\"font-size: 16px;padding:0px 3px;color:#fff;font-weight:BOLD;text-align:center; \" >" +
                                                                        "<span>BUY</span>" +
                                                                    "</td>" +

                                                                    "<td width=\"25%\" style=\"font-size: 16px;padding:0px 3px ;color:#fff;font-weight:BOLD;text-align:center; \" >" +
                                                                        "<span>SELL</span>" +
                                                                    "</td>" +

                                                                    // "<td width=\"25%\" style=\"font-size: 16px;padding:5px 3px;color:#000;font-weight:BOLD;text-align:center; \" >" +
                                                                    //     "<span>H/L</span>" +
                                                                    // "</td>" +

                        //                                                                "<td style=\"width:20%; text-align: center !Important\" >" +
                        //                                                                    "<span></span>" +
                        //                                                                "</td>" +

                        //"<td style=\"width:15%; text-align: center !Important\" >" +
                        //   "<span>L</span>" +
                        //"</td>" +
                                                                    "</tr>" +
                                                                "</table>"
                        "</td>" +
                                                            "</tr>" +
                        //Second Row
                                                                 " <tr> " +
                                                              " <td style=\"\"> ";
            //messages.length
            //messages.length
    for (var i = 3; i < 5; i++) {
        //var ret = jQuery.parseJSON(messages[i]);
        var ret = messagesDesktopp[i].split("\t");
        var oldRet;


        oldRet = messagesOldDesktop[i].split("\t");
		
		var background1 = "img/ratebox.png";


                if (ret[2].toLowerCase().includes("gold")) {
                    background1 = "#afcb1f ";
                }
               
                else if (ret[2].toLowerCase().includes("silver")) {
					
					
					background1 = "#d59969";
				}
        if (typeof ret[1] != 'undefined') {

            if (ret[3] > oldRet[3]) {

                trowString = trowString +
                //"<table width=\"100%\"><tr><td onclick=\"callBuySell('" + ret[1] + "')\" >" +
                                    "<table class=\"res_mob_font_width\"  width=\"100%\" style=\"border-collapse:separate;border-spacing:5px;\"> " +
                                        "<tr onclick=\"callBuySell('" + ret[1] + "','" + ret[2] + "');\" style=\"text-align: center;\"> " +
                                            "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:left;font-weight:700;color:#ef7f1b;text-transform:uppercase;\">" + ret[2] + "</td> " +
                                            "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                            "<span id=\"mainspan\" style=\"padding-bottom:0 !important; padding:0px 3px;font-size: 32px; color:#fff;font-weight:700;background:green;border-radius:0px;\">" + ret[3] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:red;font-weight:700;padding-bottom:0 !important;\"><br> L : " + ret[6] + "</span>" +
                                            "</td>";

            }
            else if (ret[3] < oldRet[3]) {

                trowString = trowString +
                //                                "<table width=\"100%\">"+
                //                                    "<tr>"+
                //                                        "<td>"+
                                    "<table class=\"res_mob_font_width\" width=\"100%\" style=\"border-collapse:separate;border-spacing:5px;\">" +
                                        "<tr onclick=\"callBuySell('" + ret[1] + "','" + ret[2] + "');\"  style=\"text-align: center;\">" +
                                            "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:left;font-weight:700;color:#ef7f1b;text-transform:uppercase;\">" + ret[2] + "</td>" +
                                            "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                            "<span id=\"mainspan\" style=\" padding:0px 3px;padding-bottom:0 !important; font-size: 32px; color:#fff;font-weight:700;background:red;border-radius:0px;\">" + ret[3] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:red;font-weight:700;padding-bottom:0 !important;\"><br> L : " + ret[6] + "</span>" +
                                            "</td>";

            }
            else {
                trowString = trowString +
                //                                    "<table width=\"100%\">"+
                //                                        "<tr>"+
                //                                            "<td>"+
                                        "<table class=\"res_mob_font_width\" width=\"100%\" style=\"border-collapse:separate;border-spacing:5px;\">" +
                                            "<tr onclick=\"callBuySell('" + ret[1] + "','" + ret[2] + "');\"  style=\"text-align: center;\">" +
                                                "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:left;font-weight:700;color:#ef7f1b;text-transform:uppercase;\">" + ret[2] + "</td>" +
                                                "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                                "<span id=\"mainspan\" style=\"  padding:0px 3px;font-size: 32px;color:#000;font-weight:700;padding-bottom:0 !important;\">" + ret[3] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:red;font-weight:700;padding-bottom:0 !important;\"><br> L : " + ret[6] + "</span>" +
                                                "</td>";

            }





            //For Sell

            if (ret[4] > oldRet[4]) {

                trowString = trowString +
                                "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                                "<span id=\"mainspan\" style=\" padding:0px 3px;font-size: 32px;color:#fff;font-weight:700;background:green;border-radius:0px;padding-bottom:0 !important;\">" + ret[4] + "</span>" + //<br/><span style=\"color:#8ce08c;\">H : " + ret[5] + "</span>
                "<span style=\"padding: 5px;font-size: 12px;color:green;font-weight:700;padding-bottom:0 !important;\"><br> H : " + ret[5] + "</span>" +
                                "</td>";
            }
            else if (ret[4] < oldRet[4]) {

                trowString = trowString +

                                            "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                //"<span style=\"font-size: 17px;background-color:#d0161e;border-radius:10px;color:#FFF;font-weight:700\">" + sellSmall + "</span>
                                            "<span id=\"mainspan\" style=\" padding:0px 3px;font-size: 32px;color:#fff;padding-bottom:0 !important;font-weight:700;background:red;border-radius:0px;\">" + ret[4] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:green;font-weight:700;padding-bottom:0 !important;\"><br>  H : " + ret[5] + "</span>" +
                                            "</td>";

            }
            else {
                trowString = trowString +

                                                "<td style=\"width:25%;text-align: center !Important;padding-bottom:0 ;\">" +
                //<span style=\"font-size: 17px; padding:1px 5px;padding: 3px;font-weight:700;color:#FFF\">" + sellSmall + "</span>
                                                "<span id=\"mainspan\" style=\"font-size: 32px; padding:0px 3px;font-weight:700;color:#000;padding-bottom:0 !important;\">" + ret[4] + "</span>" +
                "<span style=\"padding: 5px;font-size: 12px;color:green;font-weight:700;\"><br> H : " + ret[5] + "</span>" +
                                                "</td>";
            }



            //trowString = trowString + "</td></tr></table>";
            // trowString = trowString + "<td style=\"width: 25%;\"><span style=\"text-align: center !Important;font-size: 16px !important;color:#fff;\">" + ret[5] + "</span> / <span style=\"text-align: center !Important;font-size: 16px !important;color:#fff;\">" + ret[6] + "</span></td>";
            trowString = trowString + "</tr></table>";

            //}

        }
        oldData = data.toString();

    }
    trowString = trowString + "</td></tr></table>"; //</td></tr>





   





















    trow = $(trowString);
    trow.prependTo(zebra);



    trow_top3 = $(trowString_top3);
    trow_top3.prependTo(zebra_top3);



}
        if (counterRefresh == 0) {
            //myScroll.refresh();
            counterRefresh = counterRefresh + 1;
        }
        oldData = data.toString();
        //OnSuccessMobileTop(data, status);

    }
    catch (e) {
        //alert("OnSuccess" + e);
        oldData = data.toString();
        //alert(oldData);
    }




}
function OnError(request, status, error) {
    //alert("Webservice Error: " + request.statusText + " " + error);
}

function CallWebServiceFromJqueryGoldCoins() {
    try {
        //        $.ajax({
        //            type: "GET",
        //            url: "http://166.62.101.168:8822/VOTSBroadcast/Services/xml/GetLiveRate",
        //            dataType: "text",
        //            crossDomain: true,
        //            processData: false,
        //            success: OnSuccessGoldCoins,
        //            error: OnErrorGoldCoins,
        //            cache: false
        //        });

        $.ajax({
            type: "GET",
            //url: "http://mobiletradingbroadcast.arihantspot.com:7777/VOTSBroadcastStreaming/Services/xml/GetLiveRateByTemplateID/goldcoins",
            url: "http://" + localStorage.ipAddressBCast + ":" + localStorage.step3StreamingPort + "/VOTSBroadcastStreaming/Services/xml/GetLiveRateByTemplateID/sapnacoins",
            dataType: "text",
            crossDomain: true,
            processData: false,
            success: OnSuccessGoldCoins,
            error: OnErrorGoldCoins,
            cache: false
        });


    }
    catch (e) {
        // alert("CallWebServiceFromJquery " + e);
    }


}






//Silver Rates Monank ###########################################################################################




function OnSuccessGoldCoins(data, status) {
    // alert(data);
    try {
        // stopSpinner();
               var messages = data.split("\n");


             


        Success2_Trending_GoldRates(data, status); //OnSuccess2 Function 2

    }
    catch (e) {
        alert("OnSuccess" + e);
    }


}
function OnError_GoldRates(request, status, error) {
    //alert("Webservice Error: " + request.statusText + " " + error);
}





function Success2_Trending_GoldRates(data, status) {
    //alert(data);
    try {

        var messages = "";
        messages = data.split("\n");

        if (typeof oldDataTrending_GoldRates != 'undefined') {
        }
        else {
            oldDataTrending_GoldRates = data.toString();
        }
        var messagesOld = oldDataTrending_GoldRates.split("\n");

        if (typeof messages != 'undefined') {
            if (maxRows == 0) {
                maxRows = messages.length;
            }

          // removeAllRowsFromTable_gvData_GoldRates();
		   gvData_Trending_gvData_Trending_GoldRates();

                   var zebra_GoldRates = document.getElementById("gvData_Trending_GoldRates");

                   var trow_GoldRates;

                   var trowString = "";
				    var ret = "";
					 
                   var oldRet;
                   var trowString = "";
            ret = messages[0].split("\t");

// alert(ret[3] + '-->' + oldRet[3]);
        
			
			
			
			
			

            if (typeof ret[1] != 'undefined') {
				
                //alert(ret[3] + '-->' + oldRet[3]);

                trowString = trowString + "<table class=\"tt_33\" width=\"100%\" style=\"margin-top:0%;margin-bottom:2%;\">  " +
                                                  " <tr> " +
                                                     " <td> " +
                                                         "<table  width=\"100%\" style=\"color: #fff;margin-bottom: 5px;background:#ef7f1d;\"> " +
                                                            "<tr>" +
                                                               "<td style=\"width:50%;font-size:16px;text-align: center !Important;padding: 10px 0 10px 0px;font-weight: bold;\">" +
"<span>COINS</span>" +
                                                               "</td>" +
                                                               "<td style=\"width:50%; font-size:16px;text-align: center !Important;padding: 5px 3px;font-weight: bold;\" >" +
                                                                    "<span>995</span>" +
                                                               "</td>" +

                                                                // "<td style=\"width:25%;  font-size:16px;text-align: center !Important;padding: 5px 3px;font-weight: bold;\" >" +
                                                                    // "<span>999</span>" +
                                                               // "</td>" +

                //"<td style=\"width:15%; text-align: center !Important\" >" +
                //    "<span>HIGH</span>" +
                //"</td>" +

                //"<td style=\"width:15%; text-align: center !Important\" >" +
                //   "<span>LOW</span>" +
                //"</td>" +
                                                             "</tr>" +
                                                           "</table>"
                "</td>" +
                                                        "</tr>" +
                //Second Row
                                                     " <tr> " +
                                                  " <td> ";
                //messagesDesktopp.length
                for (var i = 3; i < messages.length; i++) {


                    //var retDesktop = jQuery.parseJSON(messages[i]);
                    var retDesktop = messages[i].split("\t");
                    var oldRetDesktop;
					
					var background1 = "img/ratebox.png";


                if (retDesktop[2].toLowerCase().includes("gold")) {
                    background1 = "transparent";
                }
               
                else if (retDesktop[2].toLowerCase().includes("silver")) {
					
					
					background1 = "transparent";
				}

                    oldRetDesktop = messagesOld[i].split("\t");
                    if (typeof retDesktop[1] != 'undefined') {

                        //if (deletedScrips[i] != "0") {
                        var buySmall = "";
                        var buyLarge = "";
                        var sellSmall = "";
                        var sellLarge = "";

                        if (retDesktop[2].length == 5) {
                            buySmall = retDesktop[3].substring(0, 2);
                            buyLarge = retDesktop[3].substring(2, 5);
                            buySmall = "";
                            buyLarge = retDesktop[3];
                        }
                        else {

                            buySmall = "";
                            buyLarge = retDesktop[3];

                        }

                        if (retDesktop[3].length == 5) {
                            sellSmall = retDesktop[4].substring(0, 2);
                            sellLarge = retDesktop[4].substring(2, 5);
                            sellSmall = "";
                            sellLarge = retDesktop[4];
                        }
                        else {

                            sellSmall = "";
                            sellLarge = retDesktop[4];

                        }

                        if (retDesktop[3] > oldRetDesktop[3]) {

                            trowString = trowString +
                            //"<table width=\"100%\"><tr><td onclick=\"callBuySell('" + retDesktop[1] + "')\" >" +
                                            "<table class=\"res_mob_font_width\"  width=\"100%\" style=\"border-collapse:separate;border-spacing:10px;\"> " +
                                                "<tr onclick=\"javascript:callBuySell('" + retDesktop[1] + "')\" style=\"text-align: center;\"> " +
                                                    "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:center;font-weight:600;color:#ef7f1d;text-transform:uppercase;background:"+background1+";\">" + retDesktop[2] + "</td> " + // small;
                                                    "<td style=\"width:50%;text-align: center !Important;padding:3px;\"><span id=\"mainspan\" style=\"padding:0px 3px;font-size: 22px;  color:#fff;font-weight:600;background:green;border-radius:0px;\">" + buySmall + "</span><span id=\"mainspan\" style=\"padding-bottom:0 !important; padding:0px 3px;font-size: 22px;  color:#fff;font-weight:600;background:green;border-radius:0px;\">" + buyLarge + "</span></td>"; //<br/><span style=\"color:red;\">L : " + retDesktop[5] + "</span>

                        }
						
						
						
						
                        else if (retDesktop[3] < oldRetDesktop[3]) {

                            trowString = trowString +
                            //                                "<table width=\"100%\">"+
                            //                                    "<tr>"+
                            //                                        "<td>"+
                                             "<table class=\"res_mob_font_width\"  width=\"100%\" style=\"border-collapse:separate;border-spacing:10px;\"> " +
                                                "<tr onclick=\"javascript:callBuySell('" + retDesktop[1] + "')\" style=\"text-align: center;\"> " +
                                                    "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:center;font-weight:600;color:#ef7f1d;text-transform:uppercase;background:"+background1+";\">" + retDesktop[2] + "</td> " + // small;
                                                    "<td style=\"width:50%;text-align: center !Important;padding:3px;\"><span id=\"mainspan\" style=\"padding:0px 3px;font-size: 22px;  color:#fff;font-weight:600;background:red;border-radius:0px;\">" + buySmall + "</span><span id=\"mainspan\" style=\"padding-bottom:0 !important; padding:0px 3px;font-size: 22px;  color:#fff;font-weight:600;background:red;border-radius:0px;\">" + buyLarge + "</span></td>"; //<br/><span style=\"color:red;\">L : " + retDesktop[5] + "</span>

                        }
                        else {
                            trowString = trowString +
                            //                                    "<table width=\"100%\">"+
                            //                                        "<tr>"+
                            //                                            "<td>"+
                                                 "<table class=\"res_mob_font_width\"  width=\"100%\" style=\"border-collapse:separate;border-spacing:10px;\"> " +
                                                "<tr onclick=\"javascript:callBuySell('" + retDesktop[1] + "')\" style=\"text-align: center;\"> " +
                                                    "<td class=\"buy_sell_label\" style=\"width:50%;padding: 5px 0px 5px 10px;text-align:center;font-weight:600;color:#ef7f1d;text-transform:uppercase;background:"+background1+";\">" + retDesktop[2] + "</td> " + // small;
                                                    "<td style=\"width:50%;text-align: center !Important;padding:3px;\"><span id=\"mainspan\" style=\"padding:0px 3px;font-size: 22px;  color:#000;font-weight:600;border-radius:0px;\">" + buySmall + "</span><span id=\"mainspan\" style=\"padding-bottom:0 !important; padding:0px 3px;font-size: 22px;  color:#000;font-weight:600;border-radius:0px;\">" + buyLarge + "</span></td>"; //<br/><span style=\"color:red;\">L : " + retDesktop[5] + "</span>

                        }





                        //For Sell

                 

                    }
                    oldDataTrending_GoldRates = data.toString();

                }
                trowString = trowString + "</td></tr></table>"; //</td></tr>
                //                trow = $(trowString);
                //                trow.prependTo(zebra);


            } //End If



        } // End -> if (typeof messagesDesktopp != 'undefined') {



        trowString = trowString + "<br><br>"; //</td></tr>



        //trowString = trowString + "<br><br><br><br><br><br><br><br><br>"; //</td></tr>

        trow_GoldRates = $(trowString);
        trow_GoldRates.prependTo(zebra_GoldRates);
        //alert(oldData_Gold_silver_INR_coins);
        oldDataTrending_GoldRates = data.toString();

        //OnSuccessGCSC_Silver(data, status); //OnSuccess2 Function 2

    }
    catch (e) {
         alert("OnSuccess : " + e);
        oldDataTrending_GoldRates = data.toString();
        //alert(oldData_Gold_silver_INR_coins);
    }


}

function OnErrorGoldCoins(){
	alert("Hello");
}






$(document).ready(function () {
    CallWebServiceFromJqueryLiveRateMessage();
    fnStartClock();
});




function CallWebServiceFromJqueryMarquee() {
    try {
        //alert("CallWebServiceFromJqueryMarquee");
        $.ajax({
            type: "GET",
            url: "http://" + localStorage.webPanel + "/WebServiceGetMarquee.asmx/getMarquee?username=" + localStorage.appnameWithMiniadminId,
            dataType: "text",
            crossDomain: true,
            processData: false,
            success: OnSuccessMarquee,
            error: OnErrorMarquee,
            cache: false
        });
    }
    catch (e) {
        //alert("CallWebServiceFromJqueryMarquee " + e);
    }


}

function OnSuccessMarquee(data, status) {
    //alert(data);
    try {

        var message = data.split("|");

        if (typeof message != 'undefined') {

            removeAllRowsFromMarquee();

            var zebra = document.getElementById("marqueeData");
            var trow;
            var trowString = "";
            trowString = trowString + convert(message[1]);

            //trow = $(trowString);
            //trow.prependTo(zebra);

            $("#marqueeData").html(trowString);
            $('.marquee').marquee({
                //speed in milliseconds of the marquee
                duration: 8000,
                //gap in pixels between the tickers
                gap: 50,
                //time in milliseconds before the marquee will start animating
                delayBeforeStart: 0,
                //'left' or 'right'
                direction: 'left',
                //true or false - should the marquee be duplicated to show an effect of continues fL
                duplicated: true,
                pauseOnHover: true
            });
        }


    }
    catch (e) {
        // alert("OnSuccessMarquee" + e);
    }


}



function OnErrorMarquee(request, status, error) {
    //alert("Webservice Error: " + request.statusText);
}

function removeAllRowsFromMarquee() {

    $("#marqueeData").empty();

}

var convert = function (convert) {

    return $("<span />", { html: convert }).text();

};
