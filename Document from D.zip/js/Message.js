



function onLoad() {
    //alert('onLoad');
    //document.addEventListener("deviceready", onDeviceReady, false);

}


function removeAllRowsFromTable() {

    $("#gvDataMessage tbody tr").remove();

}
// BILL: This keeps the total number of rows in the html table constant
function removeRowFromTable() {
    try {
        var tbl = document.getElementById('gvDataMessage');
        var lastRow = tbl.rows.length;
        //alert(maxRows);
        if (lastRow > maxRows) {
            for (i = parseInt(lastRow, 0); i >= maxRows; i--) {

                tbl.deleteRow(i - 1);
            }

        }

    }
    catch (e) {
        // alert("removeRowFromTable " + e);
    }



}

function Log(Text, MessageType) {

    try {
        if ((document.getElementById("LogContainer") == undefined)) { return; }
        if (MessageType == "OK") Text = "<span style='color: white;'>" + Text + "</span>";
        if (MessageType == "ERROR") Text = "<span style='color: red;'>" + Text + "</span>";
        document.getElementById("LogContainer").innerHTML = Text + "<br />";
        var LogContainer = document.getElementById("LogContainer");
        LogContainer.scrollTop = LogContainer.scrollHeight;

    }
    catch (e) {
        //  alert("Log" + e);

    }
}

function setIPAddress(responseText) {

    try {
        document.getElementById("iplabel").innerText = "IP Address: " + responseText;

    }

    catch (e) {
        // alert("setIPAddress" + e);
    }
}

function fnStartClock() {

    try {
        //oInterval = setInterval("CallWebServiceFromJquery()", 500);
        CallWebServiceFromJquery();
    }
    catch (e) {
        // alert("fnStartClock" + e);
    }
}

function fnStopClock() {
    try {
        //clearInterval(oInterval);
    }
    catch (e) {
        //  alert("fnStopClock" + e);
    }
}

function CallWebServiceFromJquery() {
    try {

        $.ajax({
            type: "GET",
            url: "http://" + localStorage.webPanel + "/GetMessage.asmx/GetMessagesList?username=" + localStorage.appnameWithMiniadminId,
            //url: "http://bulliontrading.chirayusoft.com/GetMessage.asmx/GetMessagesList?username=arihant",
            //url: "http://message.arihantspot.com/GetMessage.asmx/GetMessagesList",
            dataType: "text",
            crossDomain: true,
            processData: false,
            success: OnSuccess,
            error: OnError,
            cache: false
        });
    }
    catch (e) {
        //alert("CallWebServiceFromJquery " + e);
    }


}
var maxRows = 0;
var oldData;
var screenFontSize = 14;

function zoomIn() {
    try {
        if (screenFontSize <= 20) {
            screenFontSize = parseInt(screenFontSize, 0) + 1;
            //alert(screenFontSize);
            window.localStorage.setItem("screenFontSize", screenFontSize);
        }

    }
    catch (e) {
        // alert("zoomIn" + e);

    }

}
function zoomOut() {
    try {
        screenFontSize = parseInt(screenFontSize, 0) - 1;
        //alert(screenFontSize);
        window.localStorage.setItem("screenFontSize", screenFontSize);

    }
    catch (e) {
        // alert("zoomOut" + e);
    }
}
function resetMe() {
    //alert("hi");
    try {
        deletedScrips = new Array();
        for (i = 0; i < 10; i++) {
            deletedScrips[i] = "1";
        }
        maxRows = 0;
        screenFontSize = 14;
        //window.localStorage.clear();
    }
    catch (e) {
        //   alert("resetMe" + e);
    }
}

//       ; (function ($) {
//
//            // DOM Ready
//            $(function () {

//                // Binding a click event
//                // From jQuery v.1.7.0 use .on() instead of .bind()
//                $('#btnAboutUs').bind('click', function (e) {

//                    // Prevents the default action to be triggered.
//                    e.preventDefault();

//                    // Triggering bPopup when click event is fired
//                    $('#popup').bPopup();

//                });

//            });

//
//        })(jQuery);

var deletedScrips = new Array();

function deleteScrip(rowNum) {
    //alert(rowNum);
    try {
        deletedScrips[rowNum] = "0";
        maxRows = parseInt(maxRows, 0) - 1;


        window.localStorage.setItem("maxRows", maxRows);

        window.localStorage.setItem("deletedScrips", deletedScrips);
    }
    catch (e) {
        // alert("deleteScrip" + e);
    }

}

var convert = function (convert) {

    return $("<span />", { html: convert }).text();

};

function OnSuccess(data, status) {
    //alert(data);
    try {

        var messages = data.split("|");

        if (typeof messages != 'undefined') {
            if (maxRows == 0) {
                maxRows = messages.length;
            }

            removeAllRowsFromTable();
            var zebra = document.getElementById("gvDataMessage");
            var trow;
            //var trowString = "<h2 align=\"center\" style=\"color:#FFD700;\">Messages</h2>";
            var trowString = "";

            for (var i = 1; i < (messages.length - 1); i = i + 2) {

                var msg = messages[i];
                var msgDate = messages[i + 1];

                if (typeof msgDate != 'undefined') {

                    trowString = trowString +
                            "<table style=\"style=\"border-radius: 10px;border-collapse: separate;border-spacing: 1px;background: #fff;border:2px solid #e8cb90;    font-size: 1rem;	\" width=\"100%\">" +
                                "<tr style=\"text-align:left;font-size: 16px;font-weight:600;width:98%;background: #fff;\">" +
                                    "<td style=\"border-radius:10px 10px 0 0;border:0px solid #b99141;border-bottom:0px;padding: 15px;text-align: left;color: #000;box-shadow:0 0 6px 0 #676767;\">" + convert(msg) + "</td>" +
                                "</tr>" +
								"<tr style=\"color: #000;background: #fff;text-align:right !Important;font-size: 100%;font-weight:600;\">" +
                                    "<td style=\"border-radius:0px 0px 10px 10px;border:0px solid #b99141;border-top:0px;padding-right: 10px;padding-bottom: 10px;padding-top: 10px;box-shadow:0 0 6px 0 #676767;\">" + msgDate + "</td>" +
                                "</tr>" +
                                
                             "</table><br/><br/>";

                }


            }
            trow = $(trowString);
            trow.prependTo(zebra);

        }

        myScroll.refresh();

    }
    catch (e) {
        // alert("OnSuccess" + e);
    }


}



function OnError(request, status, error) {
    //alert("Webservice Error: " + request.statusText);
}

function refreshData() {
    try {
        resetMe();

        CallWebServiceFromJquery();

        fnStartClock();
    }
    catch (e) {
        // alert("refreshData" +e);
    }
}

$(document).ready(function () {

    try {
        screenFontSize = window.localStorage.getItem("screenFontSize");
        if (screenFontSize > 100) {
            screenFontSize = 14;
        }


        maxRows = window.localStorage.getItem("maxRows");

        deletedScrips = window.localStorage.getItem("deletedScrips").split(",");


    }
    catch (err) {
        resetMe();
    }

    fnStartClock();
});

var myScroll;
function loaded() {

    document.getElementById("wrapper").style.height = (window.innerHeight - (85 + 79 + 38)) + "px";
    //document.getElementById("scroller").style.height = (window.innerHeight - (0.25 * window.innerHeight)) + "px";
    //document.getElementById("wrapper").style.bottom = "185px";
    //document.getElementById("scroller").style.height = window.innerHeight;
    //document.getElementById("scroller").style.bottom = '150px';

    myScroll = new iScroll('wrapper', { hScrollbar: false, vScrollbar: true, hideScrollbar: true });

}
document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
document.addEventListener('DOMContentLoaded', loaded, false);
